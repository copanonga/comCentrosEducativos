DROP TABLE IF EXISTS `#__centroseducativos`;

<?php
defined ( '_JEXEC' ) or die ( 'Acceso ' );
?>

<h1><?php echo $this->cabecera; ?></h1>

<?php

defined ( '_JEXEC' ) or die ( 'Acceso restringido' );

class centroseducativosViewcentroseducativos extends JViewLegacy {
    
	function display($tpl = null) {
            
            $cabecera = "Centros educativos";
            $this->assignRef ( 'cabecera', $cabecera );

            if (JRequest::getVar( 'DEBUG') == "SI") {
			echo "------------------------- <br> ";
			echo "estoy en .....:". __CLASS__." <br>";
			echo "estoy en .....:". __METHOD__." <br>";
			echo "------------------------- <br> ";
		}
		/*
		 * invocar al modelo para recuperar los datos
		 */
		$item	=& $this->get('Data');
		$isNew	= ($item->id < 1);
		/* 
		 * cargar texto para el titulo
		 */
		if ($isNew) $text = JText::_( ' Nuevo' ) ;
		   else  $text = JText::_( ' Editar' );
		/*
		 * Configurar la barra de herramientas
		*/
		JToolBarHelper::title(   JText::_( 'Centros educatibos:'. $text )
				                          , 'generic.png' );
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// Si estamos editando un saludo le nombramos como CERRAR
			JToolBarHelper::cancel( 'cancel', 'Cerrar' );
		}

		$this->assignRef('item', $item);
		

            parent::display ( $tpl );
                
	}
        
}

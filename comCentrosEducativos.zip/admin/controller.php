<?php
/*
 * ********************************************************* 
 * controller.php
 * ********************************************************* 
 */

defined ( '_JEXEC' ) or die ( 'Acceso restringido' );

class centroseducativosController extends JControllerLegacy {
	
	function info() {
		parent::display ();
	}
        
}

